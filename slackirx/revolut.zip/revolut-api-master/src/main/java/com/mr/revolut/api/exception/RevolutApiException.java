package com.mr.revolut.api.exception;

public class RevolutApiException extends Exception {
    public RevolutApiException(String msg) {
        super(msg);
    }
}
