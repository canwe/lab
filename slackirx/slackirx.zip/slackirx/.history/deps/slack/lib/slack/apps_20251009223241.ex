defmodule Slack.Apps do
  @moduledoc false

  def start(token) do
    # Generate a temporary Socket Mode WebSocket URL that your app can connect to in order to receive events and interactive payloads over.
    # POST https://slack.com/api/apps.connections.open
    # application/x-www-form-urlencoded
    # application/json
    # Required arguments
    # token string
    # Authentication token bearing required scopes. Tokens should be passed as an HTTP Authorization header or alternatively, as a POST parameter.
    # Example: xxxx-xxxxxxxxx-xxxx

    reqbody = Jason.encode(%{
      token: "#{token}"
    })
    url = slack_url(token)
    headers = [{"Content-type", "application/json"}, {"Authorization", "Bearer #{token}"}]
    options = Application.get_env(:slack, :web_http_client_opts, [])
      url
      |> HTTPoison.post(reqbody, headers, options)
      |> handle_response()
    end
  end

  defp handle_response({:ok, %HTTPoison.Response{body: body}}) do
    case Jason.decode!(body, keys: :atoms) do
      %{ok: true} = json ->
        {:ok, json}

      %{error: reason} ->
        {:error, "Slack API returned an error `#{reason}.\n Response: #{body}"}

      _ ->
        {:error, "Invalid APPS response"}
    end
  rescue
    error in Jason.DecodeError ->
      %Jason.DecodeError{data: reason, position: _, token: _} = error
      {:error, %Slack.JsonDecodeError{reason: reason, string: body}}
  end

  defp handle_response(error), do: error

  defp slack_url(token) do
    Application.get_env(:slack, :url, "https://slack.com") <>
      "/api/apps.connections.open"
  end
end
