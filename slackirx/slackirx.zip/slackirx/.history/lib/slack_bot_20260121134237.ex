defmodule SlackBot do
  use Slack
  alias Slack.Sends

  @slack_token Application.compile_env(:slackirx, :slack).token
  @bot_token Application.compile_env(:slackirx, :slack).bot_token

  def handle_connect(slack, handler) do
    IO.puts("handle_connect")
    conversations = Slack.Web.Conversations.list(%{token: @slack_token, bot_token: @bot_token});
    channels = Map.merge(Map.get(slack, :channels), Map.new(Enum.map(conversations["channels"], fn x -> {x["id"], x["name"]} end)));
    IO.inspect(channels)
    Map.put(slack, :channels, channels)
    IO.inspect(Map.get(slack, :channels))
    Agent.update(SlackState, fn(_state) -> slack end)
    {:ok, handler}
  end

  def handle_event(message = %{payload: %{event: %{type: "message"}}}, slack, handler) do
    IO.puts("handle_event message")
    IO.inspect(message)
    channel_id = message.payload.event.channel
    group_chan = group_chan_from_id(channel_id, slack)
    IO.puts("channlel = #{group_chan}")

    unless is_nil(group_chan) do
      notify_handler(handler, group_chan, message, slack)
    end

    {:ok, handler}
  end

  def handle_event(_message, _slack, handler) do
    IO.puts("handle_event general")
    IO.inspect(_message)
    {:ok, handler}
  end

  def notify_handler(handler, group_chan, message, slack) do
    to_send = [
      channel: group_chan.name,
      user: slack.users[message.user].name,
      message: message,
      slack: slack
    ]

    GenEvent.notify(handler, {:slack, to_send})
  end

  def group_chan_from_id(id, slack) do
    channel = slack.channels[id]
    if is_nil(channel) do
      channel = slack.groups[id]
    end

    channel
  end

  def group_chan_from_name(name, slack) do
    groups_and_channels = Map.merge(slack.channels, slack.groups)
    Enum.find(Map.values(groups_and_channels), fn(map) -> map.name == name end)
  end

  def send_to_slack(message, channel, slack) do
    Sends.send_message(message, channel, slack)
  end
end
