defmodule Example do
  def main(num1, num2) do
    num1 + num2
    |> inspect
    |> IO.puts
  end
end
Example.add_numbers(2, 3)
