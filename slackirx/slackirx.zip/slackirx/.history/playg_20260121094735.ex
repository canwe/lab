defmodule Example do
  def main() do

  end
end
Example.main()
