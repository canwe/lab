defmodule Example do
  def main() do
    code = Code.eval_string(inspected_string)
    IO.inspect(code)
  end
end
Example.main()
