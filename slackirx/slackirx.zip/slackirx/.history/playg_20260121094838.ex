defmodule Example do
  def main() do
    code = Code.eval_string("%{a: 1, b: \"hello\"}")
    IO.inspect(code)
  end
end
Example.main()
