defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string("%{a: 1, b: \"hello\"}")
    IO.inspect(code)
  end
end
Example.main()
