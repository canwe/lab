defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string(content)
    IO.puts(code)
  end
end
Example.main()
