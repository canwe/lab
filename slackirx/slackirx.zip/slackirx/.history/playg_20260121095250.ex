defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string(content)
    IO.inspect(code["channels"])
  end
end
Example.main()
