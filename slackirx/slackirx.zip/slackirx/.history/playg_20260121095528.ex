defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string(content)
    IO.inspect(is_tuple(code))
  end
end
Example.main()
