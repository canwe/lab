defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string(content)
    IO.inspect(elem(code, 2))
  end
end
Example.main()
