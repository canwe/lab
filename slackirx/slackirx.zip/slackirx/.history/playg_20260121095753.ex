defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string(content)
    e = elem(code, 0)
    IO.inspect(is_map(e))
  end
end
Example.main()
