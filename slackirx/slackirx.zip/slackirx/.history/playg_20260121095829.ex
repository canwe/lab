defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    code = Code.eval_string(content)
    e = elem(code, 0)
    IO.inspect(e["channels"])
  end
end
Example.main()
