defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    { result, _ } =  Code.eval_string(content)
    IO.inspect(result["channels"])
  end
end
Example.main()
