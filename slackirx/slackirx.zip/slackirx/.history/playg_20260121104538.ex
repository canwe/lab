defmodule Example do
  def main() do
    content = File.read!("example.channels.json")
    { result, _ } =  Code.eval_string(content)
    list = result["channels"]
    map = Map.new(Enum.map(list, fn x -> {x["id"], x["name"]} end))
    IO.inspect(result["channels"])
  end
end
Example.main()
