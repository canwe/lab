Slackirx
========

A Slack <-> IRC relay. Originally intended as a replacement of my personal usecase of sameroom.io

Very WIP project, currently only relays one slack channel to one irc channel with no interface.


# Usage
- Get dependencies `mix deps.get`
- Configure `config/config.exs`
- Run `mix run --no-halt`
