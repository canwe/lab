# Changelog

Check https://github.com/edgurgel/httpoison/releases
