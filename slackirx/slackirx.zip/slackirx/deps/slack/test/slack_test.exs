defmodule SlackTest do
  use ExUnit.Case
end
